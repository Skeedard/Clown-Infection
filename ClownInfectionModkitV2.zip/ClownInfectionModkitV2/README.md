# PavlovVR-ModKit

Youtube playlist of class overviews
https://www.youtube.com/playlist?list=PLsnITcSCPeMo37POY0NSJWHZ8qfH7tWHD